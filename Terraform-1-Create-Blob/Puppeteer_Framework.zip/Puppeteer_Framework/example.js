const puppeteer = require("./puppeteer-framework");

const main = async () => {
  await puppeteer.launch(
    {
      inputOrder: "sequential", //random or sequential
      inputRotate: "session", //iteration or session
      uniqueSession: false, //true or false (default)
      cluster: {
        // cluster options
        timeout: 120000, // timeout in ms
        //if the steps aren't finished in this time, it will close the browser
        puppeteerOptions: {
          headless: true,
          defaultViewport: null,
          args: ["--no-sandbox", "--window-size=1920,1080"],
        }, // puppeteer options },
      },
    },
    async ({ browser, page, step, delay, data }) => {
      const user = data;
      console.log(user);
        
      //step is timed
        await step("1. Launch", async (page) => {
          await page.goto("https://www.cbre.com/", {waitUntil: "networkidle2",});
        });

        await step("2. Click on Properties", async (page) => {
            await page.click("#header > div > div > div > div > div > div.cbre-c-globalHeader__content > div > nav > div.cbre-c-globalHeader__navWrapper > ul > li:nth-child(3) > a", {waitUntil: "networkidle2",});
        });

        await step("3. Click on USA", async (page) => {
            await page.click("#section-0-i");
            await page.waitForSelector("#section-0 > ul", {visible: true,});
            await page.click("#section-0 > ul > li:nth-child(8) > a > span.cbre-c-countrySelector__country");
        }); 
    }
  );
};

main();
